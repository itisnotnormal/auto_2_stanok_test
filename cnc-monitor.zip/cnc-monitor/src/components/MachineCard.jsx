import { STATUS, formatTime } from '../data/machines'
import './MachineCard.css'

export default function MachineCard({ machine, isActive, onClick }) {
  const status = STATUS[machine.status]

  return (
    <button
      className={`card status-${machine.status} ${isActive ? 'is-active' : ''}`}
      onClick={onClick}
      style={{ '--status-color': status.color }}
    >
      <div className="card-edge" />

      <div className="card-top">
        <span className="card-code">{machine.code}</span>
        <span className="card-radar" aria-hidden="true">
          <span className="card-radar-ring" />
          <span className="card-radar-dot" />
        </span>
      </div>

      <h3 className="card-name">{machine.name}</h3>
      <p className="card-type">{machine.type}</p>

      <div className="card-status-row">
        <span className="card-status-pill">{status.label}</span>
      </div>

      <time className="card-time">{formatTime(machine.lastUpdate)}</time>
    </button>
  )
}
