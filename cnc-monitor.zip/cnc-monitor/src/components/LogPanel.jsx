import { useEffect, useRef, useState } from 'react'
import { STATUS, formatTime } from '../data/machines'
import './LogPanel.css'

export default function LogPanel({ machine, entries, onClose }) {
  const isOpen = !!machine
  const [flashId, setFlashId] = useState(null)
  const prevTopId = useRef(null)

  useEffect(() => {
    if (!entries.length) return
    const topId = entries[0].id
    if (prevTopId.current && topId !== prevTopId.current) {
      setFlashId(topId)
      const t = setTimeout(() => setFlashId(null), 900)
      return () => clearTimeout(t)
    }
    prevTopId.current = topId
  }, [entries])

  useEffect(() => {
    if (isOpen) document.body.style.overflow = 'hidden'
    else document.body.style.overflow = ''
    return () => { document.body.style.overflow = '' }
  }, [isOpen])

  return (
    <>
      <div className={`panel-scrim ${isOpen ? 'is-open' : ''}`} onClick={onClose} />
      <aside className={`panel ${isOpen ? 'is-open' : ''}`}>
        {machine && (
          <>
            <div className="panel-header" style={{ '--status-color': STATUS[machine.status].color }}>
              <div>
                <p className="panel-eyebrow">Журнал событий · станок {machine.code}</p>
                <h2 className="panel-title">{machine.name} {machine.code}</h2>
              </div>
              <button className="panel-close" onClick={onClose} aria-label="Закрыть">✕</button>
            </div>

            <div className="panel-status-row">
              <span className="panel-status-pill">{STATUS[machine.status].label}</span>
              <span className="panel-live">
                <span className="panel-live-dot" /> обновление каждые 5 сек
              </span>
            </div>

            <div className="panel-log">
              {entries.map((entry) => {
                const s = STATUS[entry.status]
                return (
                  <div
                    key={entry.id}
                    className={`log-row ${entry.id === flashId ? 'is-new' : ''}`}
                    style={{ '--row-color': s.color }}
                  >
                    <span className="log-time">{formatTime(entry.time)}</span>
                    <span className="log-status">{s.label}</span>
                  </div>
                )
              })}
            </div>
          </>
        )}
      </aside>
    </>
  )
}
