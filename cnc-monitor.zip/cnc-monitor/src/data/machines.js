// Статусы станков и их визуальные характеристики
export const STATUS = {
  work: { label: 'Работает', color: 'var(--c-work)' },
  error: { label: 'Ошибка', color: 'var(--c-error)' },
  idle: { label: 'Простой', color: 'var(--c-idle)' },
  service: { label: 'Обслуживание', color: 'var(--c-service)' },
}

// Веса для случайного перехода статусов — большую часть времени станки работают
const STATUS_WEIGHTS = [
  ['work', 60],
  ['idle', 18],
  ['service', 14],
  ['error', 8],
]

export function randomStatus() {
  const total = STATUS_WEIGHTS.reduce((sum, [, w]) => sum + w, 0)
  let roll = Math.random() * total
  for (const [key, weight] of STATUS_WEIGHTS) {
    if (roll < weight) return key
    roll -= weight
  }
  return 'work'
}

export const initialMachines = [
  { id: 'm1', code: '№1', name: 'Токарный', type: 'Токарная обработка', status: 'work' },
  { id: 'm2', code: '№2', name: 'Фрезерный', type: 'Фрезерная обработка', status: 'work' },
  { id: 'm3', code: '№3', name: 'Сверлильный', type: 'Сверление', status: 'work' },
  { id: 'm4', code: '№4', name: 'Шлифовальный', type: 'Шлифовка', status: 'work' },
  { id: 'm5', code: '№5', name: 'ЧПУ', type: 'Программная обработка', status: 'work' },
]

export function formatTime(date) {
  return date.toLocaleString('ru-RU', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).replace(',', '')
}
