import { useEffect, useRef, useState } from 'react'
import { initialMachines, randomStatus, formatTime, STATUS } from './data/machines'
import MachineCard from './components/MachineCard'
import LogPanel from './components/LogPanel'
import './App.css'

const TICK_MS = 5000
const MAX_LOGS_PER_MACHINE = 60

export default function App() {
  const [machines, setMachines] = useState(
    initialMachines.map((m) => ({ ...m, lastUpdate: new Date() }))
  )
  const [logs, setLogs] = useState(() => {
    const initial = {}
    initialMachines.forEach((m) => {
      initial[m.id] = [{ id: `${m.id}-init`, time: new Date(), status: m.status }]
    })
    return initial
  })
  const [selectedId, setSelectedId] = useState(null)
  const [connected, setConnected] = useState(true)
  const idCounter = useRef(0)

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date()
      setMachines((prev) => {
        const next = prev.map((m) => {
          // Не все станки меняют статус на каждом тике — имитация реального потока
          if (Math.random() > 0.72) return m
          const newStatus = randomStatus()
          idCounter.current += 1
          const entry = { id: `${m.id}-${idCounter.current}`, time: now, status: newStatus }
          setLogs((prevLogs) => ({
            ...prevLogs,
            [m.id]: [entry, ...(prevLogs[m.id] || [])].slice(0, MAX_LOGS_PER_MACHINE),
          }))
          return { ...m, status: newStatus, lastUpdate: now }
        })
        return next
      })
    }, TICK_MS)
    return () => clearInterval(interval)
  }, [])

  const selectedMachine = machines.find((m) => m.id === selectedId) || null

  return (
    <div className="app">
      <header className="app-header">
        <div className="app-title">
          <span className="app-title-mark">ЦЕХ</span>
          <span className="app-title-sep">/</span>
          <span className="app-title-sub">Мониторинг станков</span>
        </div>
        <div className={`conn-pill ${connected ? 'is-on' : 'is-off'}`}>
          <span className="conn-dot" />
          {connected ? 'подключено' : 'нет связи'}
        </div>
      </header>

      <p className="app-hint">Нажмите на карточку, чтобы открыть журнал событий станка в реальном времени</p>

      <main className="grid">
        {machines.map((m) => (
          <MachineCard
            key={m.id}
            machine={m}
            isActive={selectedId === m.id}
            onClick={() => setSelectedId(m.id)}
          />
        ))}
      </main>

      <LogPanel
        machine={selectedMachine}
        entries={selectedMachine ? logs[selectedMachine.id] || [] : []}
        onClose={() => setSelectedId(null)}
      />
    </div>
  )
}
